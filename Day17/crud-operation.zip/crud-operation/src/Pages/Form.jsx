import React, { useEffect, useState } from 'react'

export default function Form() {

    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const [studentData, setStudentData] = useState([]);

    console.log(studentData, "student data")



    const handleFormData = (event) => {
        event.preventDefault(); // prevent the default behaivour of form;

        // from validation check if name, email, password is empty or not
        if (!name || !email || !password) {
            alert("All input fields are required")
            return;
        }

        fetch("http://localhost:9000/student", {
            method: "POST",
            body: JSON.stringify({ name, email, password }),
            headers: { "Content-type": "application/json; charset=UTF-8" }
        })
            .then((res) => res.json())
            .then((data) => console.log(data, "data added successfully"))


        setName("");
        setEmail("")
        setPassword("")

    }


    // show data on user Interface



    useEffect(() => {
        fetch("http://localhost:9000/student")
            .then((res) => res.json())
            .then((data) => {
                setStudentData(data)
                console.log(data)
            })
            .catch((err) => console.log("something is wrong ", err))
    }, [])


    return (
        <div>
            <h1>Form</h1>
            <form onSubmit={handleFormData} >

                <input value={name} onChange={(e) => setName(e.target.value)} type="text" placeholder='Enter name' />

                <br /><br />

                <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder='Enter email' />

                <br /><br />

                <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder='Enter password' /> <br /><br />

                <button>Add</button>
            </form>



            <div>
                {
                    studentData.map((item) => {
                        return <div style={{ border: "1px solid black", margin: "10px", backgroundColor: "skyblue" }} >
                            <p>{item.id}</p>
                            <h3>{item.name}</h3>
                            <h4>{item.email}</h4>
                        </div>
                    })
                }
            </div>
        </div>
    )
}
