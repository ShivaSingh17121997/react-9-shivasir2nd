// step 1 install react-router-dom
// step 2 wrap app with BrowserRouter
// step 3 create all roues in allRoutes folder import Routes, Route from react-router-dom
// step 4 Link all the routes with provide link using Link imported from react-router-dom