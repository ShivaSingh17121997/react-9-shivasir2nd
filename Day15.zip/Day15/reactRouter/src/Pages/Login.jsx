import React from 'react'

export default function Login() {
  return (
    <div>Login 

        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus et optio doloribus, saepe, magni nemo delectus consequuntur reprehenderit repellendus ullam nostrum velit laboriosam in. Fugiat modi non quae cumque inventore.</p>
    </div>
  )
}
