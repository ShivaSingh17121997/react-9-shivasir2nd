import React from 'react'

export default function Signup() {
    return (
        <div>Signup

            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Porro quaerat provident numquam sit repellendus aperiam voluptate veniam doloremque doloribus, error, nulla ipsa vitae, perspiciatis reprehenderit vero nesciunt voluptates illum non?

            </p>
        </div>
    )
}
