import React from 'react'

export default function Contacts() {
  return (
    <div>Contacts

        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Possimus, quidem! Unde eaque id illum sint non, earum velit nostrum, molestiae ipsam fuga odio repellendus perspiciatis harum incidunt amet debitis? Porro deserunt tenetur vitae magnam libero fugiat nesciunt placeat, laborum quia exercitationem explicabo repudiandae sit dolorem autem excepturi aperiam expedita? Nulla nemo aspernatur id autem culpa qui unde quisquam aperiam error dolorem, veniam deserunt, perspiciatis doloribus officia sunt deleniti quia expedita! Fugiat iusto porro quia recusandae! Modi ratione accusantium impedit illo. Eligendi perspiciatis quam recusandae culpa quae illum repudiandae voluptas quas fuga cum temporibus saepe enim dolore esse, quis expedita sunt. Ipsum neque fugit temporibus quos, nihil, veniam unde enim aliquam cumque odit adipisci quaerat accusantium magnam. Vero esse deserunt repudiandae harum! Cupiditate non exercitationem natus perferendis esse quibusdam nihil cum alias! Cumque, tenetur repellendus minima ratione, nihil sunt, dolores provident molestias id facere corrupti et animi dolorum architecto magni? Cupiditate, minima? Ut placeat ea debitis consectetur quibusdam. Quasi optio cupiditate atque aliquid dolores consectetur quo doloremque amet eaque eius ad minus eos alias ea ipsa quae laboriosam numquam, deserunt corrupti nam ab non! Error voluptates aperiam suscipit modi asperiores iusto, necessitatibus laboriosam reprehenderit nostrum commodi nulla neque veniam obcaecati saepe!</p>
    </div>
  )
}
