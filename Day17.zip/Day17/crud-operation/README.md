



//to setup json server

1 install json server
2 script file : "server" : "json-server --watch db.json --port 9000"
3 create db.json file in main folder



// curd done
// sorting , searching, filtering, pagination 