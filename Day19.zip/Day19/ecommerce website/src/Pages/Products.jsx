import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import axios from 'axios'
import { GET_PRODUCTS } from '../redux/ActionType';
import { Link } from 'react-router-dom';

export default function Products() {
    const [search, setSearch] = useState("");
    const [category, setCategory] = useState("");
    console.log(category)

    const productData = useSelector(store => store.products);
    const dispatch = useDispatch();

    useEffect(() => {
        console.log(search)
        axios.get(`http://localhost:8000/products?q=${search}`) // promise json covert
            .then((data) => {
                console.log(data.data);
                dispatch({ type: GET_PRODUCTS, payload: data.data });
            });
    }, [search]);

    // filter by category
    let filterByCategoryData

    if (category === "") {
        filterByCategoryData = productData;
    } else {
        filterByCategoryData = productData.filter((item) => item.category === category)
    }


    return (

        <div>
            {/* searching  */}
            <div>
                <input value={search} onChange={(e) => setSearch(e.target.value)} type="text" placeholder='Search products here...' />
            </div>
            {/* filter by category */}
            <div>
                <label >
                    <input value={category} onChange={(e) => setCategory("mens")} type="checkbox" />
                    Mens
                </label>

                <label >
                    <input value={category} onChange={(e) => setCategory("womens")} type="checkbox" />
                    Womens
                </label>

                <label >
                    <input value={category} onChange={(e) => setCategory("kids")} type="checkbox" />
                    Kids
                </label>
            </div>

            {/* filter by prce*/}


            {/* showing data in ui */}
            <div className='productDiv' > {
                filterByCategoryData.map((item) => {
                    return <Link to={`/singleproductpage/${item.id}`}>
                        <div className='items' key={item.id} >
                            <img width="200px" src={item.image} alt={item.name} />
                            <h4>{item.name}</h4>
                            <p>{item.price}</p>

                        </div>
                    </Link>
                })
            }
            </div>
        </div>
    )
}
