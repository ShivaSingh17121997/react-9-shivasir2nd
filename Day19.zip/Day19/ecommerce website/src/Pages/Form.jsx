import React, { useState } from 'react';
import { useDispatch } from "react-redux";
import { ADD_PRODUCTS } from '../redux/ActionType';

export default function Form() {
    const [image, setImage] = useState("");
    const [name, setName] = useState("");
    const [price, setPrice] = useState("");
    const [quantity, setQuantity] = useState("");
    const [description, setDescription] = useState("");
    const [category, setCategory] = useState("");

    const dispatch = useDispatch()

    let products = {
        image,
        name,
        price,
        quantity,
        description,
        category
    };


    const handleProductData = (e) => {
        e.preventDefault();
        fetch("http://localhost:8000/products", {
            method: "POST",
            body: JSON.stringify(products),
            headers: {
                "Content-Type": "application/json;  charset=UTF-8",
            },
        }).then((res) => res.json())
            .then((data) => {
                dispatch({ type: ADD_PRODUCTS, payload: data }) // dispatch ==> reducer
                console.log(data)
            })
            .catch((error) => console.log(("some thing is wrong", error)));
    }



    return (
        <div>
            <form onSubmit={handleProductData} >

                <div>
                    <input value={image} onChange={(e) => setImage(e.target.value)} type="text" placeholder='Enter product image' />
                </div>

                <div>
                    <input value={name} onChange={(e) => setName(e.target.value)} type="text" placeholder='Enter product name' />
                </div>

                <div>
                    <input value={price} onChange={(e) => setPrice(e.target.value)} type="text" placeholder='Enter product price' />
                </div>

                <div>
                    <input value={quantity} onChange={(e) => setQuantity(e.target.value)} type="text" placeholder='Enter product quantity' />
                </div>

                <div>
                    <input value={description} onChange={(e) => setDescription(e.target.value)} type="text" placeholder='Enter product description' />
                </div>

                <div>
                    <select value={category} onChange={(e) => setCategory(e.target.value)} >
                        <option value="">cloths</option>
                        <option value="mens">Mens</option>
                        <option value="womens">Womens</option>
                        <option value="kids">Kids</option>
                    </select>
                </div>

                <div>
                    <button>Add</button>
                </div>

            </form>
        </div>
    )
}
