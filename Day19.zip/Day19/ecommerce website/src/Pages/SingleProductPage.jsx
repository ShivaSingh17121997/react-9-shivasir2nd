import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'

export default function SingleProductPage() {
    const [singleProdData, setSingleProdData] = useState({})
    const { id } = useParams();
    console.log(id);

    useEffect(() => {
        axios.get(`http://localhost:8000/products/${id}`)
            .then((data) => {
                console.log(data.data)
                setSingleProdData(data.data)
            })
    }, []);


    return (
        <div>
            <h1>single product page</h1>

            <img width="200px" src={singleProdData.image} alt="" />
            <h2>{singleProdData.name}</h2>
            <p>{singleProdData.price}</p>
            <p>{singleProdData.description}</p>
            <p>{singleProdData.category}</p>
            <button>Add to Cart</button>
            <button>buy now</button>
        </div>
    )
}
