import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Form from '../Pages/Form'
import Products from '../Pages/Products'
import SingleProductPage from '../Pages/SingleProductPage'

export default function AllRoutes() {
    return (
        <Routes>
            <Route path='/' element={<Form />} />
            <Route path='/products' element={<Products />} />
            <Route path='/singleproductpage/:id' element={<SingleProductPage />} />
        </Routes>
    )
}
