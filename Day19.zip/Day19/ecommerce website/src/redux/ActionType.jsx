



// Products

export const ADD_PRODUCTS = "ADD_PRODUCTS";
export const GET_PRODUCTS = "GET_PRODUCTS";
export const DELETE_PRODUCTS = "DELETE_PRODUCTS";
export const UPDATE_PRODUCTS = "UPDATE_PRODUCTS";