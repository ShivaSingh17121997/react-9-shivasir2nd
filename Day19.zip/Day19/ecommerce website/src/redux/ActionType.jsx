



// Products
export const ADD_PRODUCTS = "ADD_PRODUCTS";
export const GET_PRODUCTS = "GET_PRODUCTS";
export const DELETE_PRODUCTS = "DELETE_PRODUCTS";
export const UPDATE_PRODUCTS = "UPDATE_PRODUCTS";



// cart
export const ADD_TO_CART = "ADD_TO_CART";
export const REMOVE_FROM_CART = "REMOVE_FROM_CART";



