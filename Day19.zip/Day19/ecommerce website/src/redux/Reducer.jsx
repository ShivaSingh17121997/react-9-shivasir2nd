import React from 'react'
import { ADD_PRODUCTS, GET_PRODUCTS } from './ActionType'

const initialState = {
  products: []
}


export default function Reducer(state = initialState, action) {
  console.log(action)
  switch (action.type) {
    case ADD_PRODUCTS:
      return { ...state, products: [...state.products, action.payload] }
    case GET_PRODUCTS:
      return { ...state, products: action.payload }

    default:
      return state
  }

}
