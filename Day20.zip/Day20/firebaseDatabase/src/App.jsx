
import './App.css'
import Todo from './Todos/Todo'

function App() {

  return (
    <>
      <Todo />
    </>
  )
}

export default App
