import React, { useEffect, useState } from 'react'
import { doc, setDoc, getDoc, addDoc, collection } from "firebase/firestore";
import { db } from '../ConfigFirebase';

export default function Todo() {
    const docRef = doc(db, "Todos", "LA");
    const [todoInput, setTodoInput] = useState("");
    const [todoData, setTodoData] = useState([]);

    const handleTodos = async (e) => {
        e.preventDefault();

        try {
            // Add a new document in collection "cities"
            const docRef = await addDoc(collection(db, "todos"), {
                todo: todoInput
            });
            console.log("Document written with ID: ", docRef.id);
            setTodoInput("")

        } catch (error) {
            console.log(error)
        }
    }

    // code to get data from firebase data base
    useEffect(() => {

        async function getData() {
            const docSnap = await getDoc(docRef);

            if (docSnap.exists()) {
                console.log("Document data:", docSnap.data());
            } else {
                // docSnap.data() will be undefined in this case
                console.log("No such document!");
            }
        };

        getData()

    }, []);

    //optimizartion code splitting, chunking , lazy loading, useeeff, usememo, usecallback

    return (
        <div>
            <h2>Fire base todos</h2>

            <form onSubmit={handleTodos} >
                <input value={todoInput} onChange={(e) => setTodoInput(e.target.value)} type="text" placeholder='Enter todo' />
                <button>Add</button>
            </form>

            <div>
                {

                }


            </div>
        </div>
    )
}
